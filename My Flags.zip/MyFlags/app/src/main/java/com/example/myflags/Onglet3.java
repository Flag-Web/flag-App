package com.example.myflags;

import com.github.barteksc.pdfviewer.PDFView;
import com.github.barteksc.pdfviewer.listener.OnLoadCompleteListener;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.ListResult;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.security.spec.ECField;
import java.util.ArrayList;
import java.util.List;

public class Onglet3 extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle saveInstanceState){
        View view= inflater.inflate(R.layout.fragment_trois,container,false);

        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReferenceFromUrl("gs://my-flags.appspot.com");
        StorageReference fileRef = storageRef.child("121");

       final List<String> pdfList=new ArrayList<>();
        fileRef.listAll().addOnSuccessListener(new OnSuccessListener<ListResult>(){
            @Override
            public void onSuccess(ListResult listResult) {
                List<StorageReference> pdfFiles=new ArrayList<>();
                for (StorageReference item:listResult.getItems()){
                    if(item.getName().endsWith(".pdf")){
                        pdfFiles.add(item);
                    }
                }
                for(StorageReference file:pdfFiles){
                    pdfList.add(file.getName());
                }
                ListView listView=view.findViewById(R.id.liste);
                ArrayAdapter<String>  adapter=new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1,pdfList);
                listView.setAdapter(adapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        PDFView pdfView=view.findViewById(R.id.pdfview);
                        fileRef.listAll().addOnSuccessListener(new OnSuccessListener<ListResult>() {
                            @Override
                            public void onSuccess(ListResult listResult) {
                                for(StorageReference pdfRef:listResult.getItems()) {
                                    pdfRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                        @Override
                                        public void onSuccess(Uri uri) {
                                            pdfView.fromUri(uri).onLoad(new OnLoadCompleteListener() {
                                                @Override
                                                public void loadComplete(int nbPages) {
                                                    Toast.makeText(getContext(), "chargement du document", Toast.LENGTH_SHORT).show();
                                                }
                                            }).load();
                                        }
                                    });
                                }
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                e.printStackTrace();
                            }
                        });
                    }
                });


            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                e.printStackTrace();
            }
        });

        return view;
    }
}
