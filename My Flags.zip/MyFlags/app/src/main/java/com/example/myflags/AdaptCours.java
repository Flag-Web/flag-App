package com.example.myflags;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptCours extends RecyclerView.Adapter<AdaptCours.ViewHolder> {
    private List<Cours> cours;
    public AdaptCours(List<Cours> cours) {
        this.cours = cours;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.listitem,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Cours cour =cours.get(position);
        holder.coursNom.setText(cour.getName());
        holder.coursDescription.setText(cour.getDescription());
    }

    @Override
    public int getItemCount() {
        return cours.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{
        public TextView coursNom;
        public  TextView coursDescription;
        public ViewHolder(View view){
            super(view );
            coursNom=view.findViewById(R.id.nomcour);
            coursDescription=view.findViewById(R.id.courinfo);
        }
    }
}
